import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class GetHiddenMovieTitleTest {

	@Test
	void getHiddenMovieTitleTest() {
		Game game = new Game("movies.txt");
		String one = "Fi__i__ ____";
		String two = "F_n__n_ N___";
		String three = "_______ ___o";
		
		
		for (int i = 0; i < 3; i++) {
			game.guessLetter();
		}
		
		System.out.println(game.getHiddenMovieTitle());
		assertTrue(game.getHiddenMovieTitle().equals(one) || game.getHiddenMovieTitle().equals(two)
				|| game.getHiddenMovieTitle().equals(three) || game.getHiddenMovieTitle().equals("_______ ____"));
		
	}
}
