import static org.junit.Assert.*;

import org.junit.Test;

public class MainTest {
	/*
	 * Path 1 travels nodes (1,2,3,2,4,5,7)
	 * Where !game.gameEnded() == False so the while loop is entered once.
	 * Then game.WonGame() == True so the if statement body is executed and program concludes.
	 * SCENARIO: I guess right on second try and win
	 */
	@Test
	public void path1Test() {	
		Game game = new Game("movies.txt");
		String tracer = "", expectedResult = "";
		int counter = 0;
		
		System.out.println("The movie title has " + game.getMovieTitle().length() + " characters.");

        while(!game.gameEnded()){
            System.out.println("You have guessed (" + game.getWrongLetters().length()/2 + ") wrong letters:"
                    + game.getWrongLetters());
            game.guessLetter();   
            counter++;
            tracer = "Entered while loop " + counter + " times. ";
        }
        if(game.WonGame()){
            System.out.println("You win!");
            System.out.println("You have guessed " + game.getMovieTitle() + " correctly.");     
            tracer += "You won";
        }
        else{
            System.out.println("You have guessed (" + game.getWrongLetters().length()/2 + ") wrong letters:" +
                    game.getWrongLetters());
            System.out.println("You lost!");
            System.out.println("The movie title was " + game.getMovieTitle());
            tracer += "You lost";
        }  
        expectedResult = "Entered while loop 1 times. You won";
        assertEquals(tracer, expectedResult);
	}
	
	/*
	 * Path 2 travels nodes (1,2,4,5,7)
	 * Where !game.gameEnded() == True so the while loop is never entered.
	 * Then game.WonGame() == True so the if statement body is executed 
	 * and program concludes.
	 * SCENARIO: I guess right on first try and win
	 */
	@Test
	public void path2Test() {
		
		Game game = new Game("movies.txt");
		String tracer = "";
		int counter = 0;
		String expectedResult = "";
		
		System.out.println("The movie title has " + game.getMovieTitle().length() + " characters.");

		game.guessLetter();
        while(!game.gameEnded()){
            System.out.println("You are guessing:" + game.getHiddenMovieTitle());
            System.out.println("You have guessed (" + game.getWrongLetters().length()/2 + ") wrong letters:"
                    + game.getWrongLetters());
            game.guessLetter();
            
            counter++;
        }
        tracer = "Entered while loop " + counter + " times. ";
        if(game.WonGame()){
            System.out.println("You win!");
            System.out.println("You have guessed " + game.getMovieTitle() + " correctly.");
            
            tracer += "You won";
        }
        else{
            System.out.println("You have guessed (" + game.getWrongLetters().length()/2 + ") wrong letters:" +
                    game.getWrongLetters());
            System.out.println("You lost!");
            System.out.println("The movie title was " + game.getMovieTitle());
            System.out.println("Better luck next time.");
            tracer += "You lost";
        }
        
        expectedResult = "Entered while loop 0 times. You won";
        assertEquals(tracer, expectedResult);
	}
	
	/*
	 * Path 3 travels nodes (1,2,3,2,4,6,7)
	 * Where !game.gameEnded() == False so the while loop is entered once.
	 * Then game.WonGame() == False so the else statement body is executed 
	 * and program concludes.
	 * SCENARIO: I guess wrong on second try and lose
	 */
	@Test
	public void path3Test() {
		
		Game game = new Game("movies.txt");
		String tracer = "";
		int counter = 0;
		String expectedResult = "";
		
		System.out.println("The movie title has " + game.getMovieTitle().length() + " characters.");

        while(!game.gameEnded()){
            System.out.println("You are guessing:" + game.getHiddenMovieTitle());
            System.out.println("You have guessed (" + game.getWrongLetters().length()/2 + ") wrong letters:"
                    + game.getWrongLetters());
            game.guessLetter();
            
            counter++;
        }
        tracer = "Entered while loop " + counter + " times. ";
        if(game.WonGame()){
            System.out.println("You win!");
            System.out.println("You have guessed " + game.getMovieTitle() + " correctly.");
            
            tracer += "You won";
        }
        else{
            System.out.println("You have guessed (" + game.getWrongLetters().length()/2 + ") wrong letters:" +
                    game.getWrongLetters());
            System.out.println("You lost!");
            System.out.println("The movie title was " + game.getMovieTitle());
            System.out.println("Better luck next time.");
            tracer += "You lost";
        }
        
        expectedResult = "Entered while loop 1 times. You lost";
        assertEquals(tracer, expectedResult);
	}
	
	/*
	 * Path 4 travels nodes (1,2,4,6,7)
	 * Where !game.gameEnded() == True so the while loop is never entered.
	 * Then game.WonGame() == False so the else statement body is executed 
	 * and program concludes.
	 * SCENARIO: I guess wrong on first try and lose
	 */
	@Test
	public void path4Test() {
		
		Game game = new Game("movies.txt");
		String tracer = "";
		int counter = 0;
		String expectedResult = "";
		
		System.out.println("The movie title has " + game.getMovieTitle().length() + " characters.");

		game.guessLetter();
        while(!game.gameEnded()){
            System.out.println("You are guessing:" + game.getHiddenMovieTitle());
            System.out.println("You have guessed (" + game.getWrongLetters().length()/2 + ") wrong letters:"
                    + game.getWrongLetters());
            game.guessLetter();
            
            counter++;
        }
        tracer = "Entered while loop " + counter + " times. ";
        if(game.WonGame()){
            System.out.println("You win!");
            System.out.println("You have guessed " + game.getMovieTitle() + " correctly.");
            
            tracer += "You won";
        }
        else{
            System.out.println("You have guessed (" + game.getWrongLetters().length()/2 + ") wrong letters:" +
                    game.getWrongLetters());
            System.out.println("You lost!");
            System.out.println("The movie title was " + game.getMovieTitle());
            System.out.println("Better luck next time.");
            tracer += "You lost";
        }
        
        expectedResult = "Entered while loop 0 times. You lost";
        assertEquals(tracer, expectedResult);
	}
	
	

}
