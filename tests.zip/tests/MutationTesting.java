import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;


import org.junit.jupiter.api.Test;

class MutationTesting {

	@Test
	//Test that kills a mutant in which the default return value for gameEnded is false. 
	//Also kills a mutant in which the default gameWon variable is set to true. 
	//Also kills mutant in which first getHiddenMovieTitle is tricked into not hiding the movie title at all 
	void testGameEndedEarly() {
		Game game = new Game("movies.txt");
		boolean gameShouldbeGoing = true;
		assertTrue(gameShouldbeGoing && game.gameEnded() == false && game.WonGame() == false);
		
	}
	
	@Test
	//Test that kills a mutant in which getMovieTitle returns a movie that is not actually in the movie list 
	//Test that kills a mutant in which the MovieList adds scanner.next instead of nextLine() 
	void testMovietitleInMovieList() throws FileNotFoundException {
		Boolean movieInList = false;
		Game game = new Game("movies.txt");
		ArrayList movies = new ArrayList();
        File file = new File("movies.txt");
        
        Scanner scanner = new Scanner(file);
        while (scanner.hasNextLine()) {
        	movies.add(scanner.nextLine().trim());
        }
        
        String movieTitle = game.getMovieTitle();
        if (movies.contains(movieTitle)) movieInList = true;
        else {
        	System.out.print("Movie: " + movieTitle);
        }
		assertTrue(movieInList);
		
	}
	
	@Test 
	//Tests to make sure that an input letter is correctly sent to the wrongLetters variable
	//and that a letter that should have been was.
	//Kills mutant in which letter returned from inputLetter was not the letter sent from user input
	void testInputLetter() {
		Game game = new Game("movies.txt");
		Boolean working = true;
		String goingToInput ="Z";
		String movieTitle = game.getMovieTitle();
		game.guessLetter();
		if (game.getWrongLetters().contains(goingToInput.toLowerCase())) {
			if (!movieTitle.contains(goingToInput.toLowerCase())) {
				assertTrue(true);
			}
			else {
				System.out.print(movieTitle);
				assertTrue(false);
			}
		}
		else if (!movieTitle.contains(goingToInput.toLowerCase())) {
			assertTrue(false);
		}
		else {
			assertTrue(true);

		}
		
		
	}
	
	@Test
	//Tests to make sure that a right letter was not sent to WrongLetters on accident
	//Kills mutant in WrongLetters: return wrongletters + "e"
	void TestWrongLetters() {
		Game game = new Game("movies.txt");
		boolean assertT = true;
		String title = game.getMovieTitle();
		String wrongLetters = game.getWrongLetters();
		for (int i = 0; i < wrongLetters.length(); i++) {
			if (title.contains(wrongLetters.substring(i,  i + 1))) {
				assertT = false;
			}
		}
		assertTrue(assertT);
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}