import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import org.junit.Test;

public class MutationTest {
	
	@Test
	// Test that kills a mutant that allows the program to continue even when 
	// movies.txt is empty resulting in the game to run, then immediately end 
	// with the user winning
	public void testMovieListSize() {
		Game game = new Game("movies.txt");
		ArrayList <String> movies = new ArrayList<String>();
		//movies = new ArrayList();
        File file = new File("movies.txt");
        try {
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                movies.add(scanner.nextLine());
            }
        } catch (FileNotFoundException e) {
            System.out.println("File does not exist!");
        } finally {
        		if(movies == null) {
        			if(game.gameEnded()) {
        				assertTrue(false);
        			}
        			else {
        				assertTrue(true);
        			}
        		}
        }
        assertTrue(true);
    }
	

	@Test
	// Test that kills a mutant that allows non-letters as inputs
	public void testInputLetter() {
		Game game = new Game("movies.txt");
		String inputNonLetter = ">";
		String actualInput;
		try{
			actualInput = game.inputLetter();
			if(!actualInput.matches("[a-z]")){
				assertTrue(false);
			}
			else {
				assertTrue(true);
			}
		}
		catch(NullPointerException n){
			assertTrue(true);
		}
		assertTrue(true);
	}

	@Test
	// Test that kills a mutant that adds to the pointsLost variable even 
	// when a correct letter is guessed
	// Test that kills a mutant that does not add right letters into 
	// the rightLetters String
	public void testPointsLost() {
		Game game = new Game("movies.txt");
		String input = "a";
		String title = game.getMovieTitle();
		game.guessLetter();
		
		if(title.contains(input.toLowerCase())) {
			if(game.pointsLost == 1 && !game.rightLetters.contains(input.toLowerCase())) {
				assertTrue(false);
			}
		}
		else {
			assertTrue(true);
		}
	}
}