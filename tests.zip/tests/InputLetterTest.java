import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class InputLetterTest {

	@Test
	void inputLetterTest() {
		
		Game game = new Game("movies.txt"); // creates an instance of the hangman game.
		String wrong = " z";
		String right = "Fii ";
		
		/**
		 * This is where different test cases for inputLetter predicates are ran. 
		 * Possibilities include: valid letter (not already guessed), invalid letter, letter already guessed.
		 * 
		 * valid letter   			  	  : No response 
		 * valid letter (already guessed) : "You already guessed that letter. Guess a letter:"
		 * invalid letter 				  : "That is not a letter. Guess a letter:"
		 */
		for (int i = 0; i < 3; i++) {
			game.guessLetter();
		}
		
		/**
		 * This is where guessLetter predicate is tested.
		 * F, z, 5, f, z, i 			  : return, return, invalid, already guessed, already guessed, return
		 * wrong letters should equal " z"
		 * right letters should equal "Fii "
		 */
		assertTrue(game.getWrongLetters().equals(wrong)); // guessLetter predicate = false
		assertTrue(game.getHiddenMovieTitle().replaceAll("_", "").equals(right)); // guessLetter predicate = true
	}
}
